# Story-first homepage redesign

This version keeps the existing cinematic hero, soundtrack, contact form, gallery lightbox, responsive navigation, SEO metadata, and JavaScript behavior.

The homepage body was reorganized around a story-first experience:

- The Ride — brand manifesto and visual road strip
- Bike. Rider. Road. — three large experience panels instead of six service cards
- Dom + Lumi — moved forward as the human center of the brand
- From the Road — immersive gallery treatment
- For Mom — quieter, more intimate tribute
- Request Service — preserved as the final conversion section

The redesign is implemented in `index.html` plus a clearly marked `Story-first homepage redesign` CSS block appended to `styles.css` so it can be reviewed or rolled back easily.
