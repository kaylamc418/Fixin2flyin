# Fixin’ 2 Flyin’ PWA shell

This build adds the installable PWA shell to the story-first homepage without adding the Responses API.

## Added

- `manifest.webmanifest`
- `sw.js`
- `pwa.js`
- `offline.html`
- `assets/icons/icon-192.png`
- `assets/icons/icon-512.png`
- `assets/icons/icon-maskable-512.png`

## Updated

- `index.html`: manifest link, `viewport-fit=cover`, Apple touch icon size, and service-worker registration script.
- `styles.css`: safe-area handling, installed-display refinements, platform accent color, and UI-only text-selection behavior.

## Service worker policy

The service worker caches only the small application shell. It intentionally excludes API paths and large audio/video media. Navigation requests use the network first and fall back to `offline.html` if the network is unavailable.

## Validation

Serve the project over `http://localhost` for local testing or HTTPS in production. Do not test a service worker using a `file://` URL.

The Responses API is intentionally not included in this change.
